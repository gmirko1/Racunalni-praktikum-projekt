﻿using Adresar.UI.Forms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Adresar.UI
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Loginforma());

            //Application.Run(new PopisKontakataForm());
            /*
            using (PopisKontakataForm PopisKontakataForm = new PopisKontakataForm())
            {
                Application.Run(new Pop_up_forma());
            }*/

            /*
            using (Pop_up_forma pop_Up_Forma = new Pop_up_forma())
            {
                    Application.Run(new PopisKontakataForm());
            }*/
        }
    }
}
