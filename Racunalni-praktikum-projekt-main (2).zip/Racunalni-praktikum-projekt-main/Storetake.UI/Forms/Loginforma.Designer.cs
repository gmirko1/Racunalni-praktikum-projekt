﻿namespace Adresar.UI.Forms
{
    partial class Loginforma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_prijava = new System.Windows.Forms.Button();
            this.btn_izlaz = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbox_ime = new System.Windows.Forms.TextBox();
            this.txtbox_lozinka = new System.Windows.Forms.TextBox();
            this.btn_registracija = new System.Windows.Forms.Button();
            this.lblNaslov = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_prijava
            // 
            this.btn_prijava.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_prijava.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F);
            this.btn_prijava.Location = new System.Drawing.Point(380, 352);
            this.btn_prijava.Name = "btn_prijava";
            this.btn_prijava.Size = new System.Drawing.Size(120, 31);
            this.btn_prijava.TabIndex = 0;
            this.btn_prijava.Text = "Prijava";
            this.btn_prijava.UseVisualStyleBackColor = false;
            this.btn_prijava.Click += new System.EventHandler(this.btn_prijava_Click);
            // 
            // btn_izlaz
            // 
            this.btn_izlaz.BackColor = System.Drawing.Color.Yellow;
            this.btn_izlaz.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F);
            this.btn_izlaz.Location = new System.Drawing.Point(604, 397);
            this.btn_izlaz.Name = "btn_izlaz";
            this.btn_izlaz.Size = new System.Drawing.Size(75, 28);
            this.btn_izlaz.TabIndex = 1;
            this.btn_izlaz.Text = "Izlaz";
            this.btn_izlaz.UseVisualStyleBackColor = false;
            this.btn_izlaz.Click += new System.EventHandler(this.btn_izlaz_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(235, 152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "Korisnicko ime:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F);
            this.label2.Location = new System.Drawing.Point(238, 242);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Lozinka: ";
            // 
            // txtbox_ime
            // 
            this.txtbox_ime.Location = new System.Drawing.Point(396, 153);
            this.txtbox_ime.Name = "txtbox_ime";
            this.txtbox_ime.Size = new System.Drawing.Size(100, 20);
            this.txtbox_ime.TabIndex = 4;
            // 
            // txtbox_lozinka
            // 
            this.txtbox_lozinka.Location = new System.Drawing.Point(396, 243);
            this.txtbox_lozinka.Name = "txtbox_lozinka";
            this.txtbox_lozinka.PasswordChar = '*';
            this.txtbox_lozinka.Size = new System.Drawing.Size(100, 20);
            this.txtbox_lozinka.TabIndex = 5;
            // 
            // btn_registracija
            // 
            this.btn_registracija.BackColor = System.Drawing.Color.Red;
            this.btn_registracija.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F);
            this.btn_registracija.Location = new System.Drawing.Point(225, 352);
            this.btn_registracija.Name = "btn_registracija";
            this.btn_registracija.Size = new System.Drawing.Size(120, 31);
            this.btn_registracija.TabIndex = 6;
            this.btn_registracija.Text = "Registracija";
            this.btn_registracija.UseVisualStyleBackColor = false;
            this.btn_registracija.Click += new System.EventHandler(this.btn_registracija_Click);
            // 
            // lblNaslov
            // 
            this.lblNaslov.AutoSize = true;
            this.lblNaslov.Font = new System.Drawing.Font("Swis721 Hv BT", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNaslov.Location = new System.Drawing.Point(292, 32);
            this.lblNaslov.Name = "lblNaslov";
            this.lblNaslov.Size = new System.Drawing.Size(142, 45);
            this.lblNaslov.TabIndex = 18;
            this.lblNaslov.Text = "LOGIN";
            this.lblNaslov.Click += new System.EventHandler(this.lblNaslov_Click);
            // 
            // Loginforma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(704, 450);
            this.Controls.Add(this.lblNaslov);
            this.Controls.Add(this.btn_registracija);
            this.Controls.Add(this.txtbox_lozinka);
            this.Controls.Add(this.txtbox_ime);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_izlaz);
            this.Controls.Add(this.btn_prijava);
            this.Name = "Loginforma";
            this.Text = "0";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_prijava;
        private System.Windows.Forms.Button btn_izlaz;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtbox_ime;
        private System.Windows.Forms.TextBox txtbox_lozinka;
        private System.Windows.Forms.Button btn_registracija;
        private System.Windows.Forms.Label lblNaslov;
    }
}