﻿using Adresar.DB.Stores;
using Adresar.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Adresar.UI.Forms
{
    public partial class Loginforma : Form
    {
        public Loginforma()
        {
            InitializeComponent();
        }
           
        private void btn_prijava_Click(object sender, EventArgs e)
        {
            string GetIme = txtbox_ime.Text;
            string GetLozinka = txtbox_lozinka.Text;

            klasauredipredmete jeli_dobar_login = new klasauredipredmete();
            //jeli_dobar_login.Autorizacija(GetIme,GetLozinka);

            klasauredipredmete klasauredipredmetee = new klasauredipredmete();


            Djelatnik Djelatniklogin = new Djelatnik();
            Djelatniklogin.Ime = GetIme;
            Djelatniklogin.Lozinka = GetLozinka;


            bool provjerarazine= klasauredipredmetee.ProvjeriStatus(Djelatniklogin.Ime, Djelatniklogin.Lozinka);

            bool dobar_login = jeli_dobar_login.Autorizacija(GetIme, GetLozinka);
            if (dobar_login == true && provjerarazine==true)
            {
                PopisKontakataForm glavna_forma = new PopisKontakataForm();  
                glavna_forma.ShowDialog();
                Loginforma loginforma = new Loginforma();
                loginforma.Close();

            }
            else {
                string customMessage = "Krivo korisničko ime ili lozinka!";
                MessageBox.Show(customMessage, "Custom Dialog", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }


        }

        private void btn_izlaz_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Jeste li sigurni da želite izaći?", "Jeste li sigurni?", MessageBoxButtons.OKCancel);

            if (result == DialogResult.OK)
            {
                Application.Exit();
            }
            else if (result == DialogResult.Cancel)
            {

            }

            
        }

        private void btn_registracija_Click(object sender, EventArgs e)
        {
            forma_registracija registracija_forma = new forma_registracija();
            registracija_forma.ShowDialog();
        }

        private void lblNaslov_Click(object sender, EventArgs e)
        {

        }
    }
}

