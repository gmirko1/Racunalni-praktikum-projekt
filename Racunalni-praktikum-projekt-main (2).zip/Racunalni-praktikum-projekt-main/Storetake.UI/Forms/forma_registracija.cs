﻿using Adresar.DB.Stores;
using Adresar.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Adresar.UI.Forms
{
    public partial class forma_registracija : Form
    {
        public forma_registracija()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*string ime= txt_ime.Text;
            string prezime = txt_prezime.Text;
            string email = txt_email.Text;
            string lozinka = txt_lozinka.Text;*/

            klasadjelatnik djelatnikStore = new klasadjelatnik();
            Djelatnik djelatnik = new Djelatnik {
                 Ime= txt_ime.Text,
                 Prezime = txt_prezime.Text,
                 Email = txt_email.Text,
                 Lozinka = txt_lozinka.Text,
                 Odobren = false,
                 ID_razina = 1

        };
            djelatnikStore.Dodaj_djelatnika(djelatnik);
        }
    }
}
