﻿namespace Adresar.UI.Forms
{
    partial class AdminForma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Djelatnik_grid = new System.Windows.Forms.DataGridView();
            this.btn_odobri = new System.Windows.Forms.Button();
            this.btn_izlaz_adminforma = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Djelatnik_grid)).BeginInit();
            this.SuspendLayout();
            // 
            // Djelatnik_grid
            // 
            this.Djelatnik_grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Djelatnik_grid.Location = new System.Drawing.Point(108, 82);
            this.Djelatnik_grid.Name = "Djelatnik_grid";
            this.Djelatnik_grid.Size = new System.Drawing.Size(526, 224);
            this.Djelatnik_grid.TabIndex = 0;
            this.Djelatnik_grid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Djelatnik_grid_CellContentClick);
            // 
            // btn_odobri
            // 
            this.btn_odobri.BackColor = System.Drawing.Color.Yellow;
            this.btn_odobri.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F);
            this.btn_odobri.Location = new System.Drawing.Point(125, 342);
            this.btn_odobri.Name = "btn_odobri";
            this.btn_odobri.Size = new System.Drawing.Size(78, 32);
            this.btn_odobri.TabIndex = 1;
            this.btn_odobri.Text = "Odobri";
            this.btn_odobri.UseVisualStyleBackColor = false;
            // 
            // btn_izlaz_adminforma
            // 
            this.btn_izlaz_adminforma.BackColor = System.Drawing.Color.Yellow;
            this.btn_izlaz_adminforma.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F);
            this.btn_izlaz_adminforma.Location = new System.Drawing.Point(639, 405);
            this.btn_izlaz_adminforma.Name = "btn_izlaz_adminforma";
            this.btn_izlaz_adminforma.Size = new System.Drawing.Size(75, 33);
            this.btn_izlaz_adminforma.TabIndex = 2;
            this.btn_izlaz_adminforma.Text = "Izlaz";
            this.btn_izlaz_adminforma.UseVisualStyleBackColor = false;
            this.btn_izlaz_adminforma.Click += new System.EventHandler(this.btn_izlaz_adminforma_Click);
            // 
            // AdminForma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(755, 450);
            this.Controls.Add(this.btn_izlaz_adminforma);
            this.Controls.Add(this.btn_odobri);
            this.Controls.Add(this.Djelatnik_grid);
            this.Name = "AdminForma";
            this.Text = "AdminForma";
            ((System.ComponentModel.ISupportInitialize)(this.Djelatnik_grid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView Djelatnik_grid;
        private System.Windows.Forms.Button btn_odobri;
        private System.Windows.Forms.Button btn_izlaz_adminforma;
    }
}