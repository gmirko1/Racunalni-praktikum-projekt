﻿using Adresar.DB.Stores;
using Adresar.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Adresar.UI.Forms
{
    public partial class AdminForma : Form
    {
        public AdminForma()
        {
            InitializeComponent();
            klasadjelatnik DjelatnikStore = new klasadjelatnik();
            var djelatnik = DjelatnikStore.GetDjelatniks();
            Djelatnik_grid.DataSource = djelatnik;

            Djelatnik_grid.DataSource = DjelatnikStore.GetDjelatniks();
                       

        }
        private void Djelatnik_grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_odobri_Click(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                /*
                DataGridViewRow row = this.DjelatnikStore.Rows[e.RowIndex];

                selectedId = Convert.ToInt32(row.Cells["ID"].Value);
                odobren = row.Cells["Odobren"].Value.ToString();
                */
    
            }
        }

        private void btn_izlaz_adminforma_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}