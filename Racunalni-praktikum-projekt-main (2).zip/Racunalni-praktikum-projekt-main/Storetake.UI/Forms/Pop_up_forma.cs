﻿using Adresar.DB.Stores;
using Adresar.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Adresar.UI.Forms
{
    public partial class Pop_up_forma : Form
    {
        public string odabranaopcija;
        public int Id;
        public Pop_up_forma(int selectedId, string clickedIme, string clickedPrezime, string clickedAdresa, int clickedKolicina, string opcija)
        {
            InitializeComponent();

            txtNaziv_pop.Text = clickedIme;
            txtSifra_pop.Text = clickedPrezime;
            txtbox_jedinica_mjere_pop.Text = clickedAdresa; 
            txtbox_kolicina_pop.Text = clickedKolicina.ToString();
            //DataGridView dgKontakti = new DataGridView();
            //dgKontakti.DataSource = kontakti;
            odabranaopcija = opcija;
            selectedId = Id;
    }

        float kolicinafloat=0;
        private void btnDodaj_Click(object sender, EventArgs e)
        {
            klasauredipredmete predmetStore = new klasauredipredmete();

           
            if (odabranaopcija == "dodaj") {
                Predmet predmet = new Predmet
                {
                    Naziv = txtNaziv_pop.Text,
                    Sifra = txtSifra_pop.Text,
                    Jedinica_mjere = txtbox_jedinica_mjere_pop.Text,
                    Kolicina = kolicinafloat
                    //_kategorija = txtKategorija.Text
                };
                predmetStore.Dodaj_predmet(predmet);
                //Main_data_grid da = new Main_data_grid();
                //dgKontakti.DataSource = kontaktStore.GetKontakt();
            } else if (odabranaopcija == "azuriraj") {
                Predmet predmet = new Predmet
                {
                    ID = Id,
                    Naziv = txtNaziv_pop.Text,
                    Sifra = txtSifra_pop.Text,
                    Jedinica_mjere = txtbox_jedinica_mjere_pop.Text,
                    Kolicina = kolicinafloat
                    //_kategorija = txtKategorija.Text
                };
                predmetStore.Azuriraj_predmet(predmet);
            }
            
            //dgKontakti.DataSource = kontaktStore.GetKontakt();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNaziv_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
