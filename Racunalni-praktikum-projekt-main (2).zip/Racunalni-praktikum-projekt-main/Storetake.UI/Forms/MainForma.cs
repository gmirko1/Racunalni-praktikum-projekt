﻿using Adresar.DB.Stores;
using Adresar.Models;
using Adresar.UI.Forms;



using System;
using System.Windows.Forms;

namespace Adresar.UI
{
    public partial class PopisKontakataForm : Form
    {

        public PopisKontakataForm()
        {
            InitializeComponent();
            klasauredipredmete store = new klasauredipredmete();
            var predmet = store.GetPredmets();
            Main_data_grid.DataSource = predmet;
            
    }

        private void btnIzlaz_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show("Jeste li sigurni da se želite odjaviti?", "Jeste li sigurni?", MessageBoxButtons.OKCancel);

            if (result == DialogResult.OK)
            {
                this.Close();
            }
            else if (result == DialogResult.Cancel)
            {

            }

            
        }
        float selectedKolicina;
        private void btnDodaj_Click(object sender, EventArgs e)
        {
            string opcija = "dodaj";
            Pop_up_forma popupformica = new Pop_up_forma(selectedId, clickedIme, clickedPrezime, clickedAdresa, clickedKolicina, opcija);
            popupformica.ShowDialog();
            
        }

       
        private int selectedId;
        private string clickedIme;
        private string clickedPrezime;
        private string clickedAdresa;
        private int clickedKolicina;

        private void dgKontakti_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.Main_data_grid.Rows[e.RowIndex];

                selectedId = Convert.ToInt32(row.Cells["ID"].Value);
                clickedIme = row.Cells["Naziv"].Value.ToString();
                clickedPrezime = row.Cells["Sifra"].Value.ToString();
                clickedAdresa = row.Cells["Jedinica_mjere"].Value.ToString();
                clickedKolicina = Convert.ToInt32(row.Cells["Kolicina"].Value);
                txtIme.Text = clickedIme;
                
            }
        }

        private void btnAžuriraj_Click(object sender, EventArgs e)
        {
            klasauredipredmete predmetStore = new klasauredipredmete();

            string opcija = "azuriraj";
            Pop_up_forma popupformica = new Pop_up_forma(selectedId, clickedIme, clickedPrezime, clickedAdresa, clickedKolicina, opcija);
            popupformica.ShowDialog();

            Main_data_grid.DataSource = predmetStore.GetPredmets();
        }




        private void btnObriši_Click(object sender, EventArgs e)
        {
            klasauredipredmete predmetStore = new klasauredipredmete();

            Predmet predmetbrisi = new Predmet();
            predmetbrisi.ID = selectedId;
            predmetbrisi.Naziv = txtIme.Text;
            predmetbrisi.Jedinica_mjere = txtAdresa.Text;
            predmetbrisi.Kolicina = selectedKolicina;

            DialogResult result = MessageBox.Show("Jeste li sigurni da želite obrisati predmet?","Jeste li sigurni?", MessageBoxButtons.OKCancel);

            if (result == DialogResult.OK)
            {
                predmetStore.Zbrisi_predmet(predmetbrisi);
            }
            else if (result == DialogResult.Cancel)
            {

            }
            Main_data_grid.DataSource = predmetStore.GetPredmets();
        }

        private void btnTraži_Click(object sender, EventArgs e)
        {
            klasauredipredmete kontaktStore = new klasauredipredmete();
            Main_data_grid.DataSource = kontaktStore.Pretraga(txtTraži.Text);
        }

        private void btn_admin_Click(object sender, EventArgs e)
        {
            AdminForma adminForma = new AdminForma();
            adminForma.ShowDialog();
        }
    }
}
