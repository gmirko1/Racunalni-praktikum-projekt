﻿namespace Adresar.UI
{
    partial class PopisKontakataForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTraži = new System.Windows.Forms.TextBox();
            this.btnObriši = new System.Windows.Forms.Button();
            this.btnTraži = new System.Windows.Forms.Button();
            this.btnIzlaz = new System.Windows.Forms.Button();
            this.btnAžuriraj = new System.Windows.Forms.Button();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.txtTelefon = new System.Windows.Forms.TextBox();
            this.txtAdresa = new System.Windows.Forms.TextBox();
            this.lblNaslov = new System.Windows.Forms.Label();
            this.Main_data_grid = new System.Windows.Forms.DataGridView();
            this.txtIme = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_admin = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Main_data_grid)).BeginInit();
            this.SuspendLayout();
            // 
            // txtTraži
            // 
            this.txtTraži.Location = new System.Drawing.Point(55, 161);
            this.txtTraži.Margin = new System.Windows.Forms.Padding(2);
            this.txtTraži.Multiline = true;
            this.txtTraži.Name = "txtTraži";
            this.txtTraži.Size = new System.Drawing.Size(587, 33);
            this.txtTraži.TabIndex = 31;
            // 
            // btnObriši
            // 
            this.btnObriši.AutoSize = true;
            this.btnObriši.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnObriši.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F);
            this.btnObriši.ForeColor = System.Drawing.Color.Black;
            this.btnObriši.Location = new System.Drawing.Point(531, 500);
            this.btnObriši.Margin = new System.Windows.Forms.Padding(2);
            this.btnObriši.Name = "btnObriši";
            this.btnObriši.Size = new System.Drawing.Size(208, 38);
            this.btnObriši.TabIndex = 30;
            this.btnObriši.Text = "Obriši korisnika";
            this.btnObriši.UseVisualStyleBackColor = false;
            this.btnObriši.Click += new System.EventHandler(this.btnObriši_Click);
            // 
            // btnTraži
            // 
            this.btnTraži.AutoSize = true;
            this.btnTraži.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.btnTraži.Location = new System.Drawing.Point(673, 161);
            this.btnTraži.Margin = new System.Windows.Forms.Padding(2);
            this.btnTraži.Name = "btnTraži";
            this.btnTraži.Size = new System.Drawing.Size(66, 32);
            this.btnTraži.TabIndex = 29;
            this.btnTraži.Text = "Traži";
            this.btnTraži.UseVisualStyleBackColor = true;
            this.btnTraži.Click += new System.EventHandler(this.btnTraži_Click);
            // 
            // btnIzlaz
            // 
            this.btnIzlaz.AutoSize = true;
            this.btnIzlaz.BackColor = System.Drawing.Color.Lime;
            this.btnIzlaz.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.btnIzlaz.ForeColor = System.Drawing.Color.Black;
            this.btnIzlaz.Location = new System.Drawing.Point(762, 592);
            this.btnIzlaz.Margin = new System.Windows.Forms.Padding(2);
            this.btnIzlaz.Name = "btnIzlaz";
            this.btnIzlaz.Size = new System.Drawing.Size(62, 30);
            this.btnIzlaz.TabIndex = 28;
            this.btnIzlaz.Text = "Odjava";
            this.btnIzlaz.UseVisualStyleBackColor = false;
            this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
            // 
            // btnAžuriraj
            // 
            this.btnAžuriraj.AutoSize = true;
            this.btnAžuriraj.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnAžuriraj.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F);
            this.btnAžuriraj.ForeColor = System.Drawing.Color.Black;
            this.btnAžuriraj.Location = new System.Drawing.Point(294, 500);
            this.btnAžuriraj.Margin = new System.Windows.Forms.Padding(2);
            this.btnAžuriraj.Name = "btnAžuriraj";
            this.btnAžuriraj.Size = new System.Drawing.Size(214, 38);
            this.btnAžuriraj.TabIndex = 27;
            this.btnAžuriraj.Text = "Ažuriraj podatke";
            this.btnAžuriraj.UseVisualStyleBackColor = false;
            this.btnAžuriraj.Click += new System.EventHandler(this.btnAžuriraj_Click);
            // 
            // btnDodaj
            // 
            this.btnDodaj.AutoSize = true;
            this.btnDodaj.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnDodaj.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(226)))), ((int)(((byte)(151)))));
            this.btnDodaj.FlatAppearance.BorderSize = 0;
            this.btnDodaj.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F);
            this.btnDodaj.ForeColor = System.Drawing.Color.Black;
            this.btnDodaj.Location = new System.Drawing.Point(46, 500);
            this.btnDodaj.Margin = new System.Windows.Forms.Padding(2);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(209, 38);
            this.btnDodaj.TabIndex = 26;
            this.btnDodaj.Text = "Dodaj korisnika";
            this.btnDodaj.UseVisualStyleBackColor = false;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // txtTelefon
            // 
            this.txtTelefon.Location = new System.Drawing.Point(705, 57);
            this.txtTelefon.Margin = new System.Windows.Forms.Padding(2);
            this.txtTelefon.Name = "txtTelefon";
            this.txtTelefon.Size = new System.Drawing.Size(54, 20);
            this.txtTelefon.TabIndex = 25;
            // 
            // txtAdresa
            // 
            this.txtAdresa.Location = new System.Drawing.Point(579, 57);
            this.txtAdresa.Margin = new System.Windows.Forms.Padding(2);
            this.txtAdresa.Name = "txtAdresa";
            this.txtAdresa.Size = new System.Drawing.Size(90, 20);
            this.txtAdresa.TabIndex = 24;
            // 
            // lblNaslov
            // 
            this.lblNaslov.AutoSize = true;
            this.lblNaslov.Font = new System.Drawing.Font("Swis721 Hv BT", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNaslov.Location = new System.Drawing.Point(307, 19);
            this.lblNaslov.Name = "lblNaslov";
            this.lblNaslov.Size = new System.Drawing.Size(208, 45);
            this.lblNaslov.TabIndex = 17;
            this.lblNaslov.Text = "StoreTake";
            // 
            // Main_data_grid
            // 
            this.Main_data_grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Main_data_grid.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.Main_data_grid.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Main_data_grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Main_data_grid.GridColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Main_data_grid.Location = new System.Drawing.Point(46, 221);
            this.Main_data_grid.Margin = new System.Windows.Forms.Padding(2);
            this.Main_data_grid.Name = "Main_data_grid";
            this.Main_data_grid.RowHeadersWidth = 51;
            this.Main_data_grid.RowTemplate.Height = 24;
            this.Main_data_grid.Size = new System.Drawing.Size(693, 247);
            this.Main_data_grid.TabIndex = 16;
            this.Main_data_grid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgKontakti_CellClick);
            // 
            // txtIme
            // 
            this.txtIme.Location = new System.Drawing.Point(147, 114);
            this.txtIme.Margin = new System.Windows.Forms.Padding(2);
            this.txtIme.Name = "txtIme";
            this.txtIme.Size = new System.Drawing.Size(108, 20);
            this.txtIme.TabIndex = 32;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(52, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 33;
            this.label1.Text = "Označeno: ";
            // 
            // btn_admin
            // 
            this.btn_admin.BackColor = System.Drawing.Color.Yellow;
            this.btn_admin.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_admin.Location = new System.Drawing.Point(672, 592);
            this.btn_admin.Name = "btn_admin";
            this.btn_admin.Size = new System.Drawing.Size(67, 30);
            this.btn_admin.TabIndex = 34;
            this.btn_admin.Text = "Admin";
            this.btn_admin.UseVisualStyleBackColor = false;
            this.btn_admin.Click += new System.EventHandler(this.btn_admin_Click);
            // 
            // PopisKontakataForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(835, 633);
            this.Controls.Add(this.btn_admin);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtIme);
            this.Controls.Add(this.txtTraži);
            this.Controls.Add(this.btnObriši);
            this.Controls.Add(this.btnTraži);
            this.Controls.Add(this.btnIzlaz);
            this.Controls.Add(this.btnAžuriraj);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.lblNaslov);
            this.Controls.Add(this.Main_data_grid);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "PopisKontakataForm";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.Main_data_grid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTraži;
        private System.Windows.Forms.Button btnObriši;
        private System.Windows.Forms.Button btnTraži;
        private System.Windows.Forms.Button btnIzlaz;
        private System.Windows.Forms.Button btnAžuriraj;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.TextBox txtTelefon;
        private System.Windows.Forms.TextBox txtAdresa;
        //private System.Windows.Forms.TextBox txtPrezime;
        private System.Windows.Forms.Label lblNaslov;
        private System.Windows.Forms.DataGridView Main_data_grid;
        private System.Windows.Forms.TextBox txtIme;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_admin;
    }
}

