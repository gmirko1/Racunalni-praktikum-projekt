﻿namespace Adresar.UI.Forms
{
    partial class Pop_up_forma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtbox_kolicina_pop = new System.Windows.Forms.TextBox();
            this.txtbox_jedinica_mjere_pop = new System.Windows.Forms.TextBox();
            this.txtSifra_pop = new System.Windows.Forms.TextBox();
            this.txtNaziv_pop = new System.Windows.Forms.TextBox();
            this.lblIme = new System.Windows.Forms.Label();
            this.lblBrojTel = new System.Windows.Forms.Label();
            this.lblAdresa = new System.Windows.Forms.Label();
            this.lblPrezime = new System.Windows.Forms.Label();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.txtbox_Kategorija = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtbox_kolicina_pop
            // 
            this.txtbox_kolicina_pop.Location = new System.Drawing.Point(509, 95);
            this.txtbox_kolicina_pop.Margin = new System.Windows.Forms.Padding(2);
            this.txtbox_kolicina_pop.Name = "txtbox_kolicina_pop";
            this.txtbox_kolicina_pop.Size = new System.Drawing.Size(167, 20);
            this.txtbox_kolicina_pop.TabIndex = 33;
            // 
            // txtbox_jedinica_mjere_pop
            // 
            this.txtbox_jedinica_mjere_pop.Location = new System.Drawing.Point(509, 54);
            this.txtbox_jedinica_mjere_pop.Margin = new System.Windows.Forms.Padding(2);
            this.txtbox_jedinica_mjere_pop.Name = "txtbox_jedinica_mjere_pop";
            this.txtbox_jedinica_mjere_pop.Size = new System.Drawing.Size(167, 20);
            this.txtbox_jedinica_mjere_pop.TabIndex = 32;
            // 
            // txtSifra_pop
            // 
            this.txtSifra_pop.Location = new System.Drawing.Point(119, 98);
            this.txtSifra_pop.Margin = new System.Windows.Forms.Padding(2);
            this.txtSifra_pop.Name = "txtSifra_pop";
            this.txtSifra_pop.Size = new System.Drawing.Size(167, 20);
            this.txtSifra_pop.TabIndex = 31;
            // 
            // txtNaziv_pop
            // 
            this.txtNaziv_pop.Location = new System.Drawing.Point(119, 56);
            this.txtNaziv_pop.Margin = new System.Windows.Forms.Padding(2);
            this.txtNaziv_pop.Name = "txtNaziv_pop";
            this.txtNaziv_pop.Size = new System.Drawing.Size(167, 20);
            this.txtNaziv_pop.TabIndex = 30;
            this.txtNaziv_pop.TextChanged += new System.EventHandler(this.txtNaziv_TextChanged);
            // 
            // lblIme
            // 
            this.lblIme.AutoSize = true;
            this.lblIme.Font = new System.Drawing.Font("Arial Narrow", 13F);
            this.lblIme.Location = new System.Drawing.Point(45, 54);
            this.lblIme.Name = "lblIme";
            this.lblIme.Size = new System.Drawing.Size(54, 22);
            this.lblIme.TabIndex = 29;
            this.lblIme.Text = "Naziv: ";
            // 
            // lblBrojTel
            // 
            this.lblBrojTel.AutoSize = true;
            this.lblBrojTel.Font = new System.Drawing.Font("Arial Narrow", 13F);
            this.lblBrojTel.Location = new System.Drawing.Point(404, 95);
            this.lblBrojTel.Name = "lblBrojTel";
            this.lblBrojTel.Size = new System.Drawing.Size(68, 22);
            this.lblBrojTel.TabIndex = 28;
            this.lblBrojTel.Text = "Kolicina: ";
            // 
            // lblAdresa
            // 
            this.lblAdresa.AutoSize = true;
            this.lblAdresa.Font = new System.Drawing.Font("Arial Narrow", 13F);
            this.lblAdresa.Location = new System.Drawing.Point(404, 54);
            this.lblAdresa.Name = "lblAdresa";
            this.lblAdresa.Size = new System.Drawing.Size(111, 22);
            this.lblAdresa.TabIndex = 27;
            this.lblAdresa.Text = "Jedinica mjere: ";
            // 
            // lblPrezime
            // 
            this.lblPrezime.AutoSize = true;
            this.lblPrezime.Font = new System.Drawing.Font("Arial Narrow", 13F);
            this.lblPrezime.Location = new System.Drawing.Point(45, 95);
            this.lblPrezime.Name = "lblPrezime";
            this.lblPrezime.Size = new System.Drawing.Size(47, 22);
            this.lblPrezime.TabIndex = 26;
            this.lblPrezime.Text = "Sifra: ";
            // 
            // btnDodaj
            // 
            this.btnDodaj.AutoSize = true;
            this.btnDodaj.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(226)))), ((int)(((byte)(151)))));
            this.btnDodaj.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(226)))), ((int)(((byte)(151)))));
            this.btnDodaj.FlatAppearance.BorderSize = 0;
            this.btnDodaj.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.btnDodaj.ForeColor = System.Drawing.Color.White;
            this.btnDodaj.Location = new System.Drawing.Point(238, 273);
            this.btnDodaj.Margin = new System.Windows.Forms.Padding(2);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(116, 30);
            this.btnDodaj.TabIndex = 34;
            this.btnDodaj.Text = "Dodaj";
            this.btnDodaj.UseVisualStyleBackColor = false;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // txtbox_Kategorija
            // 
            this.txtbox_Kategorija.Location = new System.Drawing.Point(119, 168);
            this.txtbox_Kategorija.Margin = new System.Windows.Forms.Padding(2);
            this.txtbox_Kategorija.Name = "txtbox_Kategorija";
            this.txtbox_Kategorija.Size = new System.Drawing.Size(167, 20);
            this.txtbox_Kategorija.TabIndex = 36;
            this.txtbox_Kategorija.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 13F);
            this.label1.Location = new System.Drawing.Point(32, 165);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 22);
            this.label1.TabIndex = 37;
            this.label1.Text = "Kategorija: ";
            // 
            // Pop_up_forma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtbox_Kategorija);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.txtbox_kolicina_pop);
            this.Controls.Add(this.txtbox_jedinica_mjere_pop);
            this.Controls.Add(this.txtSifra_pop);
            this.Controls.Add(this.txtNaziv_pop);
            this.Controls.Add(this.lblIme);
            this.Controls.Add(this.lblBrojTel);
            this.Controls.Add(this.lblAdresa);
            this.Controls.Add(this.lblPrezime);
            this.Name = "Pop_up_forma";
            this.Text = "Pop_up_forma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtbox_kolicina_pop;
        private System.Windows.Forms.TextBox txtbox_jedinica_mjere_pop;
        private System.Windows.Forms.TextBox txtSifra_pop;
        private System.Windows.Forms.TextBox txtNaziv_pop;
        private System.Windows.Forms.Label lblIme;
        private System.Windows.Forms.Label lblBrojTel;
        private System.Windows.Forms.Label lblAdresa;
        private System.Windows.Forms.Label lblPrezime;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.TextBox txtbox_Kategorija;
        private System.Windows.Forms.Label label1;
    }
}