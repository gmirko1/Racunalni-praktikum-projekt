﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adresar.Models
{
    public class Predmet
    {
        public int ID { get; set; }
        public string Naziv { get; set; }
        public string Sifra { get; set; }
        public string Jedinica_mjere { get; set; }
        public float Kolicina { get; set; }
        //blic string ID_kategorija { get; set; }
    }

    public class Djelatnik {
        public int ID { get; set; }
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public string Lozinka { get; set; }
        public string Email { get; set; }
        public bool Odobren { get; set; }
        public int ID_razina { get; set; }
    }
}
