﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using Adresar.Models;
using System.Linq;


namespace Adresar.DB.Stores
{
    public class klasauredipredmete
    {
        public List<Predmet> GetPredmets()
        {
            var connectionManager = new SqlConnectionFactory();
            List<Predmet> userList = new List<Predmet>();

            using (var connection = connectionManager.GetNewConnection())
            {
                if (connection != null)
                {
                    string upit = String.Format("SELECT * FROM predmet");

                    using (var command = new MySqlCommand(upit, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        { 
                            
                            while (reader.Read())  
                            {
                                Predmet predmet = new Predmet();    
                                predmet.ID = reader.GetInt32("Id");
                                predmet.Naziv = reader.GetString("Naziv");
                                predmet.Sifra = reader.GetString("Sifra");
                                predmet.Jedinica_mjere = reader.GetString("Jedinica_mjere");

                                predmet.Kolicina = reader.GetFloat("Kolicina");
                                userList.Add(predmet);
                            }
                        }
                    }
                }
                connectionManager.CloseConnection(connection);
            }
            return userList.OrderBy(predmet => predmet.Naziv).ToList();
        }


        private string GetConnectionString()
        {
            string connString = "Server=localhost;Database=storetake;Uid=root;Pwd=root;";
            return connString;
        }



        public bool Autorizacija(string korisnickoIme, string lozinka)
        {

            var connection = new MySqlConnection(GetConnectionString());
            bool postoji = false;
            connection.Open();

            var command = new MySqlCommand("SELECT * FROM Djelatnik WHERE ime = @korisnickoIme AND Lozinka = @lozinka", connection);
            command.Parameters.AddWithValue("@korisnickoIme", korisnickoIme);
            command.Parameters.AddWithValue("@lozinka", lozinka);

            var reader = command.ExecuteReader();

            while (reader.Read())
            {
                postoji = reader.HasRows;
            }
            return postoji;
        }

        public bool ProvjeriStatus(string ime, string lozinka)
        {
            var connection = new MySqlConnection(GetConnectionString());
            bool odobrenStatus = false;

            try
            {
                connection.Open();

                var command = new MySqlCommand("SELECT Odobren FROM djelatnik " +
                                              "WHERE Ime = @Ime AND Lozinka = @Lozinka AND Odobren = 1", connection);
                command.Parameters.AddWithValue("@Ime", ime);
                command.Parameters.AddWithValue("@Lozinka", lozinka);

                using (var reader = command.ExecuteReader())
                {
                    odobrenStatus = reader.HasRows;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }

            return odobrenStatus;
        }


        public void Odobri_djelatnika(Djelatnik djelatnik)
        {
            var connectionManager = new SqlConnectionFactory();

            using (var connection = connectionManager.GetNewConnection())
            {
                if (connection != null)
                {
                    string upit = "UPDATE Djelatnik SET Ime = @Ime, Prezime = @Prezime,  Odobren = @Odobren, Lozinka = @Lozinka, Email = @email WHERE id = @Id";

                    using (var command = new MySqlCommand(upit, connection))
                    {
                        command.Parameters.AddWithValue("@Id", djelatnik.ID);
                        command.Parameters.AddWithValue("@Ime", djelatnik.Ime);
                        command.Parameters.AddWithValue("@Prezime", djelatnik.Prezime);
                        command.Parameters.AddWithValue("@Odobren", djelatnik.Odobren);
                        command.Parameters.AddWithValue("@Lozinka", djelatnik.Lozinka);
                        command.Parameters.AddWithValue("@Email", djelatnik.Email);

                        command.ExecuteNonQuery();
                    }

                    connectionManager.CloseConnection(connection);
                }
            }
        }


        public void Dodaj_predmet(Predmet predmet)
        {
            var connectionManager = new SqlConnectionFactory();

            using (var connection = connectionManager.GetNewConnection())
            {
                if (connection != null)
                {
                    string upit = "INSERT INTO predmet(Naziv, Sifra, Jedinica_mjere, Kolicina) " +
                                  "VALUES(@Naziv, @Sifra, @Jedinica_mjere, @Kolicina)";

                    using (var command = new MySqlCommand(upit, connection))
                    {
                        command.Parameters.AddWithValue("@Naziv", predmet.Naziv);
                        command.Parameters.AddWithValue("@Sifra", predmet.Sifra);
                        command.Parameters.AddWithValue("@Jedinica_mjere", predmet.Jedinica_mjere);
                        command.Parameters.AddWithValue("@Kolicina", predmet.Kolicina); 

                        command.ExecuteNonQuery();
                    }

                    connectionManager.CloseConnection(connection);
                }
            }
        }

        public void Azuriraj_predmet(Predmet predmet)
        {
            var connectionManager = new SqlConnectionFactory();

            using (var connection = connectionManager.GetNewConnection())
            {
                if (connection != null)
                {
                    string upit = "UPDATE predmet SET Naziv = @Naziv, Sifra = @Sifra, Jedinica_mjere = @Jedinica_mjere, Kolicina = @Kolicina WHERE id = @Id";

                    using (var command = new MySqlCommand(upit, connection))
                    {
                        command.Parameters.AddWithValue("@Id", predmet.ID);
                        command.Parameters.AddWithValue("@Naziv", predmet.Naziv);
                        command.Parameters.AddWithValue("@Sifra", predmet.Sifra);
                        command.Parameters.AddWithValue("@Jedinica_mjere", predmet.Jedinica_mjere);
                        command.Parameters.AddWithValue("@Kolicina", predmet.Kolicina);

                        command.ExecuteNonQuery();
                    }

                    connectionManager.CloseConnection(connection);
                }
            }
        }

        public void Zbrisi_predmet(Predmet predmet) {
            var connectionManager = new SqlConnectionFactory();
            using (var connection = connectionManager.GetNewConnection())
            {
                if (connection != null)
                {
                    string upit = "DELETE FROM predmet WHERE id = @Id";

                    using (var command = new MySqlCommand(upit, connection))
                    {
                        command.Parameters.AddWithValue("@Id", predmet.ID);
                        command.ExecuteNonQuery();
                    }

                    connectionManager.CloseConnection(connection);
                }
            }
        }


        public void odobriDjelatnika(Djelatnik djelatnik)
        {
            var connectionManager = new SqlConnectionFactory();

            using (var connection = connectionManager.GetNewConnection())
            {
                if (connection != null)
                {
                    string upit = "UPDATE djelatnik SET Odobren = @Odobren WHERE id = @Id";

                    using (var command = new MySqlCommand(upit, connection))
                    {
                        command.Parameters.AddWithValue("@Id", djelatnik.ID);
                        command.Parameters.AddWithValue("@Odobren", djelatnik.Odobren);
  

                        command.ExecuteNonQuery();
                    }

                    connectionManager.CloseConnection(connection);
                }
            }
        }


        public List<Predmet> Pretraga( string traži)
        {
            klasauredipredmete predmetStore = new klasauredipredmete();
            var pretrazipredmet = predmetStore.GetPredmets();
            List<Predmet> rezultati = pretrazipredmet.Where(predmet => predmet.Naziv.IndexOf(traži, StringComparison.OrdinalIgnoreCase) >= 0 ||
            predmet.Sifra.IndexOf(traži, StringComparison.OrdinalIgnoreCase) >= 0 ||
            predmet.Naziv.IndexOf(traži, StringComparison.OrdinalIgnoreCase) >= 0).ToList();
            return rezultati;
        }
    }
}
