﻿using Adresar.Models;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adresar.DB.Stores
{
    public class klasadjelatnik
    {
        public List<Djelatnik> GetDjelatniks()
        {
            var connectionManager = new SqlConnectionFactory();
            List<Djelatnik> userList = new List<Djelatnik>();

            using (var connection = connectionManager.GetNewConnection())
            {
                if (connection != null)
                {
                    string upit = String.Format("SELECT * FROM Djelatnik");

                    using (var command = new MySqlCommand(upit, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {

                            while (reader.Read())
                            {
                                Djelatnik noviDjelatnik = new Djelatnik();   
                                noviDjelatnik.ID = reader.GetInt32("Id");
                                noviDjelatnik.Ime = reader.GetString("Ime");
                                noviDjelatnik.Prezime = reader.GetString("Prezime");
                                noviDjelatnik.Lozinka = reader.GetString("Lozinka");
                                noviDjelatnik.Odobren = reader.GetBoolean("Odobren");
                                noviDjelatnik.Email = reader.GetString("Email");
                                userList.Add(noviDjelatnik);
                            }
                        }
                    }
                }
                connectionManager.CloseConnection(connection);
            }
            return userList.OrderBy(noviDjelatnik => noviDjelatnik.Ime).ToList();
        }





        public void Dodaj_djelatnika(Djelatnik djelatnik)
        {
            var connectionManager = new SqlConnectionFactory();

            using (var connection = connectionManager.GetNewConnection())
            {
                if (connection != null)
                {
                    string upit = "INSERT INTO djelatnik(Ime, Prezime, ID_Razina, Odobren, Lozinka,email) " +
                                  "VALUES(@Ime, @Prezime, @ID_Razina, @Odobren,  @Lozinka, @email)";

                    using (var command = new MySqlCommand(upit, connection))
                    {
                        command.Parameters.AddWithValue("@Ime", djelatnik.Ime);
                        command.Parameters.AddWithValue("@Prezime", djelatnik.Prezime);
                        command.Parameters.AddWithValue("@ID_Razina", djelatnik.ID_razina);
                        command.Parameters.AddWithValue("@Odobren", djelatnik.Odobren);
                        command.Parameters.AddWithValue("@Lozinka", djelatnik.Lozinka);
                        command.Parameters.AddWithValue("@email", djelatnik.Email);

                        command.ExecuteNonQuery();
                    }

                    connectionManager.CloseConnection(connection);
                }
            }
        }

        public bool ProvjeraRazine(Djelatnik djelatnik)
        {
            var connectionManager = new SqlConnectionFactory();

            using (var connection = connectionManager.GetNewConnection())
            {
                if (connection != null)
                {
                    string upit = "SELECT Odobren FROM djelatnik " +
                                  "WHERE Ime = @Ime AND Lozinka = @Lozinka AND Odobren = @Odobren";

                    using (var command = new MySqlCommand(upit, connection))
                    {
                        command.Parameters.AddWithValue("@Ime", djelatnik.Ime);
                        command.Parameters.AddWithValue("@Lozinka", djelatnik.Lozinka);
                        command.Parameters.AddWithValue("@Odobren", djelatnik.Odobren);

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                bool odobrenFromDatabase = reader.GetBoolean(0);
                                return odobrenFromDatabase;
                            }
                            else
                            {
                                return false;
                            }
                        }
                    }
                }
                else
                {
                    return false;
                }
            }
        }




    }

}
